var x = 0;
function mycount()
{
    if(x<100)
    y = setTimeout(counter,50);
}

function counter()
{
    var val = document.getElementById("num").innerHTML;
    val++;
    document.getElementById("num").innerHTML = val;
    x++;
    mycount();   

}
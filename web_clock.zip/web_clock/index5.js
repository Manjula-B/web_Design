function mytime()
{
    var d=new Date();
    var hh=d.getHours();
    var mm=d.getMinutes();
    var ss=d.getSeconds();
    
    time_str = hh + ":"+ mm + ":" +ss;
    document.getElementById("time").innerHTML= time_str;
    setTimeout(mytime,1000);
}


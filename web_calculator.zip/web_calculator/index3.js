function calculate(oper)
{
    x=prompt("Please enter a= ")
    y=prompt("Please enter b= ")
    res=0;
    op="";
    switch(oper)
    {
        case '+': res=parseFloat(x) + parseFloat(y);op="ADD : " ; break;
        case '-': res=parseFloat(x) - parseFloat(y);op="SUBTRACT : " ; break;
        case '*': res=parseFloat(x) * parseFloat(y);op="MULTIPLY : " ; break;
        case '%': res=parseFloat(x) % parseFloat(y);op="DIVIDE : " ; break;
    }
    document.getElementById("a").innerHTML="a= " + x;
    document.getElementById("b").innerHTML="b= " + y;
    document.getElementById("Result").innerHTML= op + res;
}

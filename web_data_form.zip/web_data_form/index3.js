function getme()
{

    var mystring = "";
    //input from text box
    var user= document.getElementById("user").value;
    var pass= document.getElementById("passd").value;
    var gen=document.getElementsByName('gender');

    mystring = user + " "+pass + " ";

    var gender;

    for(var i=0; i<gen.length;i++)
    {
        if(gen[i].checked){
            mystring += gen[i].value;
            gender = gen[i].value;
            break;
        }
    }
    var interest = document.getElementById("interest").value;
    mystring += " " + interest;
    

    var course = document.getElementById("course");
    var cval = course.options[course.selectedIndex].value;
    mystring += " " + cval;


    var dob=document.getElementById("birthday").value;
    mystring += " " + dob;


    alert(mystring);

    createDate("USER NAME",user,0);
    createDate("GENDER",gender,1);
    createDate("INTEREST",interest,2);
    createDate("COURSE",cval,3);
    createDate("DOB",dob,4);


}

function createDate(s1,s2,r)
{
    var table=document.getElementById("details");

    var row = table.insertRow(r);

    var c1=row.insertCell(0);
    var c2=row.insertCell(1);

    c1.innerHTML = s1;
    c2.innerHTML = s2;


}